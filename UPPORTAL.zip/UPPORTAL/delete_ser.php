<?php
    session_start();
    include_once('./include/dbcon.php');

    if(isset($_GET['id'])){
        $database = new Connection();
        $db = $database -> open();
        try{
            $sql = "DELETE FROM servicio WHERE MATRICULA = '".$_GET['id']."'";
            $_SESSION['message'] = ($db->exec($sql)) ? 'Equipo eliminado correctamente' : 'No se pudo eliminar el equipo, revisa los datos';
        }catch(PDOException $e){
            $_SESSION['message'] = $e->getMessage();
        }
        $database->close();
    }
    else{
        $_SESSION['message'] = 'Llene completamente el formulario';
    }
    header('location: servicio_vista.php');

?>
