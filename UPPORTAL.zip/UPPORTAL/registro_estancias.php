<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./public/css/bootstrap.min.css">
    <link rel="stylesheet" href="./styles_alumno.css">
    <link rel="stylesheet" href="./styles_serviciosec.css">
    <link rel="stylesheet" href="./styles_registro.css">
    <link rel="stylesheet" href="cl-icon/css/all.min.css">
    <link rel="stylesheet" href="functions.js">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <title>REGISTRO ESTANCIAS</title>
</head>
<body class="body2">
    <header>
        <div class="logo-nav-container">
            <nav class="nav-bar ">
                <ul>
                    <li><img class="imgalum" src="./public/imagenes/logotipopaginaprin.jpg" alt=""></li>
                    <li><a href="./login.php" class="titulosnav">SALIR</a></li>
                    <li><a href="./alumnosprin.php" class="titulosnav">principal</a></li>

                </ul>
            </nav>
        </div>
    </header>
   <center> <div class="carta">
        <div class="registro-formulario">
            <h1>Registro de estancias</h1>
            <form action="./add_estancia.php" method="POST">
                <div class="campo">
                    <label for="nombre">NOMBRES:</label>
                    <input type="text" id="nombre" name="nombre" required>
                </div>
                <div class="campo">
                    <label for="carrera">CARRERA:</label>
                    <input type="text" id="carrera" name="carrera" required>
                </div>
                <div class="campo">
                    <label for="cuatri">CUATRIMESTRE:</label>
                    <input type="text" id="cuatri" name="cuatri" required>
                </div>
                <div class="campo">
                    <label for="id_estancia">MATRICULA:</label>
                    <input type="text" id="id_estancia" name="id_estancia" required>
                </div>
                <div class="campo">
                    <label for="confirm">Realizando estancia:</label>
                    <input type="text" id="confirm" name="confirm" required>
                </div>
                <div class="campo">
                    <label for="horas_esta">Horas de Conteo:</label>
                    <input type="number" id="horas_esta" name="horas_esta" required>
                </div>
                <div class="boton">
                    <button type="submit" class="boton-degradado2 botonsee"  name="agregar">Guardar Datos</button>
                </div>
            </form>
        </div>
    </div>
</center>
</body>
</html>