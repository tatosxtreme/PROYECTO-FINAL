<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./public/css/bootstrap.min.css">
    <link rel="stylesheet" href="./styles_alumno.css">
    <link rel="stylesheet" href="./styles_serviciosec.css">
    <link rel="stylesheet" href="cl-icon/css/all.min.css">
    <link rel="stylesheet" href="functions.js">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <title>ADMINISTRADORES</title>
</head>
<body class="body2">
    <header>
        <div class="logo-nav-container">
            <nav class="nav-bar ">
                <ul>
                    <li><img class="imgalum" src="./public/imagenes/logotipopaginaprin.jpg" alt=""></li>
                    <li><a href="./login.php" class="titulosnav">Log In</a></li>
                </ul>
            </nav>
        </div>
    </header>
<body>
    <div class="column col-6dos">
    </div>
        <center>
        <div class="carta2">
                <h1 href="./" class="cuatri titcart">CONSULTA ALUMNOS</h1>
                <br>

                <br>
                <center><a href="./vista_general_alumno.php" class="submit alumnoing">vista alumno</a></center>

                <br>
            </div>
            <h1 class="moretitle"> POSIBLES CONSULTAS DISPONIBLES</h1>
            <br> <br>
            <div class="carta2">
                <h1 href="./" class="cuatri titcart"> CUATRIMESTRE 1-5</h1>
                <br>

                <br>
                <center><a href="./servicio_vista.php" class="boton-degradado botonsee">CONSULTA SERVICIO</a></center>

                <br>
            </div>
            <div class="carta2">
                <h1 href="./" class="cuatri titcart ">CUATRIMESTRE 6-7</h1>
                <br>

                <br>
                <center><a href="./estancias_vista.php" class="boton-degradado botonsee">CONSULTA ESTANCIA</a></center>

                <br>
            </div>
            <div class="carta2">
                <h1 href="./" class="cuatri titcart">DECIMO CUATRIMESTRE</h1>
                <br>

                <br>
                <center><a href="./estadia_vista.php" class="boton-degradado botonsee">CONSULTA ESTADIA</a></center>

                <br>
            </div>
          

    <br>
                
            </div>
           
        </center>
        
    </div>
</body>
<footer>
    <div class="footer-container">
        <div class="footer-content">
            <p>&copy; 2023 UPP Web Wizards
            </p>
        </div>
    </div>
</footer>
</html>