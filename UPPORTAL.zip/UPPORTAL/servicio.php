<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./public/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles_alumno.css">
    <link rel="stylesheet" href="styles_serviciosec.css">
    <link rel="stylesheet" href="cl-icon/css/all.min.css">
    <link rel="stylesheet" href="functions.js">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <title>SERVICIO SOCIAL</title>
</head>

<body class="body2">
    <header>
        <div class="logo-nav-container">
            <nav class="nav-bar ">
                <ul>
                    <li><img class="imgalum" src="./public/imagenes/logotipopaginaprin.jpg" alt=""></li>
                    <li><a href="./login.php" class="titulosnav">SALIR</a></li>
                    <li><a href="./alumnosprin.php" class="titulosnav">Principal</a></li>
                    <li><a href="./estancias.php" class="titulosnav">Estancias</a></li>
                    <li><a href="./estadias.php" class="titulosnav">Estadias</a></li>
                </ul>
            </nav>
        </div>
    </header>
    <center>
        <div>
            <div class="column col-8">
                <h1 class="alumnostit"> INFORMACION GENERAL DE SERVICIO SOCIAL
                </h1>
            </div>
        </div>
        <div>
    </center>

    <div class="column col-6dos">
        <center>
            <h1 class="moretitle"> SERVICIO SOCIAL EN UPP</h1>
            <br>
            <div class="bg4 ">
                <p class="parrafo parrafoserv">El servicio social en nuestro programa educativo es una experiencia enriquecedora que trasciende las aulas y conecta a los estudiantes con la comunidad. Al colaborar con diversas instituciones, los alumnos aplican sus conocimientos en entornos del mundo real, fortaleciendo habilidades, fomentando el compromiso cívico y contribuyendo al bienestar social. Este compromiso va más allá de cumplir con horas, se trata de entender las necesidades de la sociedad y aportar soluciones significativas. El programa no solo forma profesionales competentes, sino ciudadanos conscientes y comprometidos con el impacto positivo. Es una oportunidad invaluable para crecer, aprender y dejar una huella positiva en la comunidad que nos rodea.</p>

            </div>

        </center>

    </div>
    <div class="contenedoralu">
    <div class="carta">
        <h2 class="tituloserv">Proceso de Realizar Servicio Social:
        </h2>
        <p>
            <ul>
                <li class="alumnotitulo">Elección de la Institución:</li>
                <p></p>
                <p class="parrafoserv"> Selecciona una institución o entidad en la que desees realizar tu servicio social. Puede ser una organización no gubernamental (ONG), una institución gubernamental, una empresa privada, entre otras.</p>
                <li class="alumnotitulo">Contacto y Aprobación:</li>
                <p></p>
                <p class="parrafoserv">Ponte en contacto con la institución elegida y verifica si aceptan estudiantes para realizar servicio social. Es posible que debas presentar una solicitud y obtener la aprobación.</p>
                <li class="alumnotitulo">Acuerdo o Convenio:</li>
                <p></p>
                <p class="parrafoserv">En muchos casos, la institución y tu institución educativa (universidad o centro de estudios) deben firmar un acuerdo o convenio para formalizar la realización del servicio social.</p>
                <li class="alumnotitulo">Planificación:</li>
                <p></p>
                <p class="parrafoserv">Planifica las actividades que realizarás durante tu servicio social en coordinación con la institución. Esto podría incluir proyectos específicos, asistencia en programas existentes, investigación, entre otros.</p>
            </ul></p>
           
      </div>
      <div class="column col-6dosser">
<center><img class="imagen" src="./public/imagenes/imagenservicio1.jpg" alt="">
    <br>
    <img class="imagen" src="./public/imagenes/imagenservicio2.jpg" alt=""></center>



    </div>
      </div>
      <div class="contenedoralu">
        <div class="column col-serv">
            
<center><h2 class="titcart">Ejecución del Servicio Social:</h2> </center>

            <p class="parrafoserv2">Lleva a cabo las actividades planificadas de acuerdo con los lineamientos establecidos por la institución y tu programa educativo.</p>
          </div>
          <div class="column col-serv">
          
<center> <h2 class="titcart">Registro de Horas:</h2></center>

            <p class="parrafoserv2">Es común que debas llevar un registro de las horas dedicadas al servicio social. Esto puede ser necesario para obtener el reconocimiento oficial.</p>
          </div>
          <div class="column col-serv">
           
<center><h2 class="titcart">Horas de Servicio Social:</h2></center>

            <p class="parrafoserv2">La cantidad de horas requeridas puede variar según las políticas de la institución educativa y las regulaciones locales. En algunos casos, se establece un mínimo de horas para cumplir con los requisitos del programa.</p>
          </div>
          <div class="column col-serv">
            
<center><h2 class="titcart">Informe y Evaluación:</h2></center>

            <p class="parrafoserv2">Al finalizar, prepara un informe que detalle las actividades realizadas. La institución y tu institución educativa pueden evaluar tu desempeño durante el servicio social.</p>
          </div>
        </div>
        

        <div class="contenedoralu">
            <div class="column col-serv">
                <center><h2 class="titcart"> Certificación:</h2></center>
                <p class="parrafoserv2"> Una vez completado el servicio social y cumplidos los requisitos, es posible que obtengas una certificación o constancia que valide tu participación.</p>
              </div>
              <div class="column col-serv">
               <center><h2 class="titcart">Tipos de Instituciones:</h2></center> 
                <p class="parrafoserv2">Las oportunidades para realizar servicio social son diversas y pueden incluir:
                    <ul>
                        <li>Organizaciones no gubernamentales (ONG)</li>
                        <li>Instituciones gubernamentales (dependiendo de la legislación local)</li>
                        <li>Hospitales y centros de salud.</li>
                        <li>Escuelas y centros educativos</li>
                        <li>Proyectos comunitarios.</li>
                    </ul>
                    </p>
              </div>
             
            </div>
      </div>
      <br>
      <br>
      <div>
       <center>
        <a href="./registro_servicio.php" class="boton-degradado  botonsee">Registro de Servicio Social</a>
        <a href="./servicio_vista_alumno.php" class="boton-degradado botonsee">Consulta servicio alumnado</a>

    </center> 

</body>

      </div>
    <script src="/functions.js" crossorigin=""></script>
    <script src="styles_alumno.css"></script>
    <script src="styles_serviciosec.css"></script>
</body>
<br>
<footer>
    <div class="footer-container">
        <div class="footer-content">
            <p>&copy; 2023 UPP Web Wizards
            </p>
        </div>
    </div>
</footer>

</html>