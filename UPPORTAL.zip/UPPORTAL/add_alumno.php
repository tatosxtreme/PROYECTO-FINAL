<?php
session_start();
include_once('./include/dbcon.php');

if (isset($_POST['agregar'])) {
    $database = new Connection();
    $bd = $database->open();

    try {
        $stmt = $bd->prepare("INSERT INTO general (NOMBRES, CARRERA, CUATRIMESTRE, MATRICULA) VALUES (:nombre, :carrera, :cuatri, :id)");
        $stmt->bindParam(':nombre', $_POST['nombre']);
        $stmt->bindParam(':carrera', $_POST['carrera']);
        $stmt->bindParam(':cuatri', $_POST['cuatri']);
        $stmt->bindParam(':id', $_POST['id']);

        $_SESSION['message'] = $stmt->execute() ? 'Alumno guardado correctamente' : 'Algo salió mal, no se guardó correctamente el alumno';
    } catch (PDOException $e) {
        $_SESSION['message'] = $e->getMessage();
    }

    $database->close();
} else {
    $_SESSION['message'] = 'Llene completamente el formulario';
}

header('location:login.php');
?>
