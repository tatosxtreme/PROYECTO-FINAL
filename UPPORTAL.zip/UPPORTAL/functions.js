const temaOscuro = () => {
    document.querySelector("body").setAttribute("data-bs-theme", 
    "dark");
}

const temaClaro = () => {
    document.querySelector("body").setAttribute("data-bs-theme", 
    "light");
}

const cambiarTema = () => {
    document.querySelector("body").getAttribute("data-bs-theme") === "light"? temaOscuro() : temaClaro();
}

// cambiarColor.js

function changeTitleColor() {
    const titulo = document.getElementById("per-titulo");
    const colors = ["red", "blue", "green", "purple", "orange"];
    const randomColor = colors[Math.floor(Math.random() * colors.length)];
    titulo.style.color = randomColor;
  }
  
  
  
 