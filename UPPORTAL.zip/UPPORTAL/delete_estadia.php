<?php
    session_start();
    include_once('./include/dbcon.php');

    if(isset($_GET['id'])){
        $database = new Connection();
        $db = $database -> open();
        try{
            $sql = "DELETE FROM estadia WHERE MATRICULA = '".$_GET['id']."'";
            $_SESSION['message'] = ($db->exec($sql)) ? 'alumno eliminado correctamente' : 'No se pudo eliminar el alumno, revisa los datos';
        }catch(PDOException $e){
            $_SESSION['message'] = $e->getMessage();
        }
        $database->close();
    }
    else{
        $_SESSION['message'] = 'Llene completamente el formulario';
    }
    header('location: estadia_vista.php');

?>
