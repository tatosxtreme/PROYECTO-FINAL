<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./public/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="./styles_registro.css">
    <link rel="stylesheet" href="./styles_serviciosec.css">
    <link rel="stylesheet" href="./styles_alumno.css">
    <title>ALUMNOS REGISTRADOS</title>
</head>
<body class="body2">
    <div class="row mx-auto">
        <table class="tabla">
            <thead>
                <tr>
                    <th>NOMBRES</th>
                    <th>CARRERA</th>
                    <th>CUATRIMESTRE</th>
                    <th>MATRICULA</th>
                </tr>
            </thead>
            <tbody>
                <?php
                include_once("include/dbcon.php");
                $database = new connection();
                $bd = $database->open();
                try {
                    $sql = 'SELECT * FROM general';
    
                    foreach ($bd->query($sql) as $row) {
                        ?>
                        <tr>
                            <td><?php echo $row['NOMBRES'] ?></td>
                            <td><?php echo $row['CARRERA'] ?></td>
                            <td><?php echo $row['CUATRIMESTRE'] ?></td>
                            <td><?php echo $row['MATRICULA'] ?></td>
                        </tr>
                        <?php
                    }
                } catch (PDOException $e) {
                    echo 'Error en la consulta' . $e->getMessage() . ''; /*Error en la consulta*/
                }
                $database->close();
                ?>
            </tbody>
        </table>
    </div>
  
                <center><a href="./adminprin.php" class="submit alumnoing">PAGINA PRINCIPAL</a></center>

</body>
</html>