<!DOCTYPE html>
<html lang="en">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./public/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="./styles_registro.css">
    <link rel="stylesheet" href="./styles_serviciosec.css">
    <link rel="stylesheet" href="./styles_alumno.css">
    <title>servicio</title>
</head>
<body class="body2">
    <div class="row mx-auto">
        <table class="tabla">
            <thead>
                <tr>
                    <th>NOMBRES</th>
                    <th>CARRERA</th>
                    <th>CUATRIMESTRE</th>
                    <th>MATRICULA</th>
                    <th>Realizando Servicio</th>
                    <th>conteo de horas</th>
                    <th>ELIMINAR ALUMNO</th>
                    <th>EDITAR ALUMNO</th>
                </tr>
            </thead>
            <tbody>
                <?php
                include_once("include/dbcon.php");
                $database = new connection();
                $bd = $database->open();
                try {
                    $sql = 'SELECT * FROM estancia WHERE CUATRIMESTRE BETWEEN 6 AND 7';
    
                    foreach ($bd->query($sql) as $row) {
                        ?>
                        <tr>
                            <td><?php echo $row['NOMBRES'] ?></td>
                            <td><?php echo $row['CARRERA'] ?></td>
                            <td><?php echo $row['CUATRIMESTRE'] ?></td>
                            <td><?php echo $row['MATRICULA'] ?></td>
                            <td><?php echo $row['realizando_estancia'] ?></td>
                            <td><?php echo $row['horas'] ?></td>


                            <td>
                            <form action="./delete_estan.php" method="GET">
                                    <input type="hidden" name="id" value="<?php echo $row['MATRICULA']; ?>">
                                    <button type="submit" class="btn btn-danger" onclick="return confirm('¿Estás seguro de eliminar este alumno?')">Eliminar</button>
                                </form>
                            </td>

                            <td>
    <form action="./edit_estan.php" method="POST">
        <input type="hidden" name="id" value="<?php echo $row['MATRICULA']; ?>">
        <label for="horas_<?php echo $row['MATRICULA']; ?>" class="form-label">Editar Horas de Servicio</label>
        <input type="text" id="horas_<?php echo $row['MATRICULA']; ?>" name="horas" class="form-control" required autofocus>
        <button type="submit" class="btn btn-primary" name="editar">Guardar</button>
    </form>
</td>
                        </tr>
                        <?php
                    }
                } catch (PDOException $e) {
                    echo 'Error en la consulta' . $e->getMessage() . ''; /*Error en la consulta*/
                }
                $database->close();
                ?>
            </tbody>
        </table>
    </div>
  
                <center><a href="./adminprin.php" class="submit alumnoing">PAGINA PRINCIPAL</a></center>

</body>
</html>