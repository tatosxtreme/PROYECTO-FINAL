<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./public/css/bootstrap.min.css">
    <link rel="stylesheet" href="./styles_alumno.css">
    <link rel="stylesheet" href="./styles_serviciosec.css">
    <link rel="stylesheet" href="cl-icon/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <title>UPPORTAL</title>
</head>
<body class="body">
    <div class="wrapper">
    <form action="./add_alumno.php" method="POST" class="form">
    <h1 class="title alumnotit">INICIO</h1>
    <div class="inp">
        <input type="text" name="nombre" id="nombre" class="input" placeholder="NOMBRE(S)">
        <i class="fa-solid fa-user"></i>
    </div>
    <div class="inp">
        <input type="text" name="carrera" id="carrera" class="input" placeholder="CARRERA">
        <i class="fa-solid fa-user"></i>
    </div>
    <div class="inp">
        <input type="text" name="cuatri" id="cuatri" class="input" placeholder="Cuatrimestre">
        <i class="fa-solid fa-lock"></i>
    </div>
    <div class="inp">
        <input type="text" name="id" id="id" class="input" placeholder="Matricula">
        <i class="fa-solid fa-lock"></i>
    </div>
    <br>
    <button class="botonbase alumnogua" name="agregar">Guardar datos</button>
    <a href="./alumnosprin.php" class="submit alumnoing">Ingresa alumno</a>
    <a href="admin_authentication.php" class="submit alumnoing">Ingresa Admin</a>

</form>

        <div></div>
        <div class="banner">
            <img class="imglogo"src="./public/imagenes/logo 2.jpg" alt="">
        </div>
    </div>
    
      <script src="/functions.js" crossorigin=""></script>
    <script src="./styles_alumno.css"></script>
</body>
</html>