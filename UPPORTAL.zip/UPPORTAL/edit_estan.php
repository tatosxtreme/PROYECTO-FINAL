<?php
session_start();
include_once('include/dbcon.php');

if (isset($_POST['editar'])) {
    $database = new Connection();
    $db = $database->open();
    
    try {
        $id = $_POST['id']; // Verifica si realmente necesitas obtener el 'id' desde $_GET
        $horas_conteo = $_POST['horas']; // Corrige el nombre del campo

        $sql = "UPDATE estancia SET horas = '$horas_conteo' WHERE MATRICULA = '$id'";

        $_SESSION['message'] = ($db->exec($sql)) ? 'Historia actualizada correctamente' : 'No se puede actualizar la historia';
    } catch (Exception $e) {
        $_SESSION['message'] = $e->getMessage(); // Utiliza getMessage() en lugar de getPrevious()
    }

    $database->close();
} else {
    $_SESSION['message'] = 'Llene completamente el formulario';
}

header('location:estancias_vista.php');
?>