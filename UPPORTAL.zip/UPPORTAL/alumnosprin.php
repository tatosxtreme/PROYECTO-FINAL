<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./public/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles_alumno.css">
    <link rel="stylesheet" href="styles_serviciosec.css">
    <link rel="stylesheet" href="cl-icon/css/all.min.css">
    <link rel="stylesheet" href="functions.js">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

    <title>ALUMNOS PORTAL</title>
</head>

<body class="body2">
    <header>
        <div class="logo-nav-container">
            <nav class="nav-bar ">
                <ul>
                    <li><img class="imgalum" src="./public/imagenes/logotipopaginaprin.jpg" alt=""></li>
                    <li><a href="./login.php" class="titulosnav">SALIR</a></li>
                    <li><a href="./servicio.php" class="titulosnav">Servicio social</a></li>
                    <li><a href="./estancias.php" class="titulosnav">Estancias</a></li>
                    <li><a href="./estadias.php" class="titulosnav">Estadias</a></li>
                </ul>
            </nav>
        </div>
    </header>
    <center>
        <div>
            <div class="column col-8">
                <h1 class="alumnostit"> INFORMACION GENERAL DEL ALUMNO
                </h1>
            </div>
        </div>
        <div>
    </center>
    <div class="contenedoralu">
        <div class="column col-3">

            <h1 class="titulosalumnos">Bienvenido correcamino!!!!!!</h1>
            <p class="parrafo">Bienvenidos a nuestra escuela, donde la educación es una prioridad y cada estudiante es
                fundamental en nuestro compromiso con el aprendizaje y el desarrollo integral. La "Información General
                del Alumno" es un componente esencial para entender y apoyar a cada uno de nuestros estudiantes de
                manera efectiva.

                La "Información General del Alumno" engloba diversos aspectos cruciales que nos permiten conocer y
                atender las necesidades individuales de cada estudiante. Este conjunto de datos proporciona una visión
                integral de su identidad académica y personal, permitiéndonos personalizar su experiencia educativa para
                maximizar su éxito.</p>
            <center> <img class="imglogo2" src="./public/imagenes/referencial.jpg" alt="">
            </center>
            <br>
            <p class="frase">"Al igual que el Correcaminos nunca se detiene en su búsqueda del éxito, persiste en tu
                viaje educativo; cada esfuerzo te acerca a tus metas."</p>
        </div>
        <div class="column col-6dos">
            <center>
                <h1 class="moretitle">SERVICIOS Y ARCHIVOS GENERALES</h1>
            </center>
            <br>

            <div class=" column col-md-auto bg">
                <center>
                    <h1 class="moretitle2">¿Que es el servicio social?</h1>
                    <p class="parrafo2">El servicio social es una contribución voluntaria de estudiantes al bienestar
                        comunitario. Inicia desde los primeros cuatrimestres, brindando experiencia práctica y
                        promoviendo responsabilidad ciudadana. Para detalles, se recomienda contactar a servicios
                        escolares.</p>
                </center>
            </div>

            <br>

            <div class=" column col-md-auto bg2">
                <center>
                    <h1 class="moretitle2">¿Que son las estancias?</h1>
                    <p class="parrafo2">Las estancias, en el contexto académico, generalmente se refieren a períodos de
                        prácticas o experiencias profesionales que los estudiantes llevan a cabo como parte de su
                        formación universitaria. Estas experiencias suelen realizarse durante el último año de la
                        universidad y proporcionan a los estudiantes la oportunidad de aplicar sus conocimientos
                        teóricos en entornos prácticos. Las estancias pueden ser en empresas, instituciones u
                        organizaciones relacionadas con su campo de estudio. Esta inmersión práctica no solo enriquece
                        la formación académica, sino que también facilita la transición de los estudiantes al mundo
                        laboral al adquirir experiencia relevante.
                    </p>
                </center>
            </div>

            <br>

            <div class=" column col-md-auto bg3">
                <center>
                    <h1 class="moretitle2">¿Que es la estadia?</h1>
                    <p class="parrafo2">se refiere a una práctica profesional final diseñada para retener al estudiante
                        dentro de la empresa después de completar su formación. Esta modalidad busca no solo brindar una
                        experiencia práctica al estudiante, sino también fomentar su integración a largo plazo en la
                        organización.

                        Durante la "estadia", los estudiantes tienen la oportunidad de aplicar sus conocimientos
                        académicos en situaciones laborales reales, al tiempo que la empresa tiene la posibilidad de
                        evaluar el desempeño y las habilidades del estudiante como parte de su posible incorporación
                        permanente al equipo laboral. Este enfoque busca establecer una conexión más sólida entre la
                        formación académica y las necesidades del empleador.
                    </p>
                </center>
            </div>



        </div>

    </div>
    <div>
</div>
    <div class="column col-6dos">
        <center>
            <h1 class="moretitle"> POSIBLES CONSULTAS DISPONIBLES</h1>
            <div class="bg4 ">
                <p class="parrafo">RECUERDA!!</p>
            <P class="parrafo">Debes acudir a servicios escolares antes de realizar cualquier consulta dentro de este portal y asi poder estar seguro de lo que deseas hacer </P>
            </div>
            <br> <br>
            <div class="carta2">
                <h1 href="./" class="cuatri titcart"> CUATRIMESTRE 1-5</h1>
                <br>

                <center><a href="./registro_servicio.php" class="boton-degradado botonsee">REGISTRO SERVICIO</a></center>
                <br>
                <center><a href="./servicio_vista_alumno.php" class="boton-degradado botonsee">CONSULTA SERVICIO</a></center>

                <br>
            </div>
            <div class="carta2">
                <h1 href="./" class="cuatri titcart ">CUATRIMESTRE 6-7</h1>
                <br>

                <center><a href="./registro_estancias.php" class="boton-degradado botonsee">REGISTRO ESTANCIA</a></center>
                <br>
                <center><a href="./estancias_vista_alumno.php" class="boton-degradado botonsee">CONSULTA ESTANCIA</a></center>

                <br>
            </div>
            <div class="carta2">
                <h1 href="./" class="cuatri titcart">DECIMO CUATRIMESTRE</h1>
                <br>

                <center><a href="./registro_estadia.php" class="boton-degradado botonsee">REGISTRO ESTADIA</a></center>
                <br>
                <center><a href="./estadia_vista_alumno.php" class="boton-degradado botonsee">CONSULTA ESTADIA</a></center>

                <br>
            </div>
          

    <br>
                
            </div>
           
        </center>
        
    </div>
    <br>
    



    <script src="styles_alumno.css"></script>
    <script src="./functions.js"></script>
</body>
<footer>
    <div class="footer-container">
        <div class="footer-content">
            <p>&copy; 2023 UPP Web Wizards
            </p>
        </div>
    </div>
</footer>

</html>