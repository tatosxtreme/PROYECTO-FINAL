<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./public/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles_alumno.css">
    <link rel="stylesheet" href="styles_serviciosec.css">
    <link rel="stylesheet" href="cl-icon/css/all.min.css">
    <link rel="stylesheet" href="functions.js">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <title>ESTANCIAS</title>
</head>
<body class="body2">
    <header>
        <div class="logo-nav-container">
            <nav class="nav-bar ">
                <ul>
                    <li><img class="imgalum" src="./public/imagenes/logotipopaginaprin.jpg" alt=""></li>
                    <li><a href="./login.php" class="titulosnav">SALIR</a></li>
                    <li><a href="./alumnosprin.php" class="titulosnav">Principal</a></li>
                    <li><a href="./servicio.php" class="titulosnav">servicio social</a></li>
                    <li><a href="./estadias.php" class="titulosnav">Estadias</a></li>
                </ul>
            </nav>
        </div>
    </header>
    <center>
        <div>
            <div class="column col-8">
                <h1 class="alumnostit"> INFORMACION GENERAL DE ESTANCIAS
                </h1>
            </div>
        </div>
        <div>
    </center>

    <div class="column col-6dos">
        <center>
            <h1 class="moretitle"> ESTANCIAS EN UPP</h1>
            <br>
            <div class="bg4 ">
                <p class="parrafo parrafoserv">
                    Las prácticas profesionales son cruciales en la formación académica, permitiendo a los estudiantes aplicar conocimientos teóricos en entornos reales. Proporcionan experiencia laboral temprana, desarrollan habilidades profesionales específicas, y exploran carreras. Estas experiencias construyen redes profesionales, fomentan adaptabilidad y resiliencia, y preparan para el mundo laboral. Además, contribuyen a la innovación y fortalecen la autoconfianza. Al cumplir requisitos curriculares, las prácticas son esenciales para una educación integral, ofreciendo una transición fluida al mercado laboral y asegurando que los estudiantes estén preparados y competitivos en sus futuras carreras..</p>

            </div>

        </center>

    </div>

    <div class="contenedoralu">
        <div class="carta">
            <h2 class="tituloserv">Proceso de Realizar Estancias:
            </h2>
            <p>
                <ul>
                    <li class="alumnotitulo">Elección de la Institución o Empresa:</li>
                    <p></p>
                    <p class="parrafoserv"> Seleccionar la entidad o empresa donde se llevarán a cabo las prácticas, considerando la afinidad con la carrera y los objetivos profesionales.</p>
                    <li class="alumnotitulo">Contacto y Aprobación:</li>
                    <p></p>
                    <p class="parrafoserv">Establecer contacto con la institución y obtener la aprobación para realizar las prácticas. Esto puede implicar presentar una solicitud y participar en entrevistas.</p>
                    <li class="alumnotitulo">Acuerdo o Convenio:</li>
                    <p></p>
                    <p class="parrafoserv">Firmar acuerdos o convenios entre la institución educativa y la entidad donde se realizarán las prácticas. Estos documentos establecen las condiciones, responsabilidades y beneficios para ambas partes.</p>
                    <li class="alumnotitulo">Planificación:</li>
                    <p></p>
                    <p class="parrafoserv">Elaborar un plan de trabajo en coordinación con la institución, definiendo las tareas y objetivos específicos de las prácticas.</p>
                </ul></p>
               
          </div>
          <div class="column col-6dosser">
    <center><img class="imagen" src="./public/imagenes/pf3.jpg" alt="">
        <br>
        <img class="imagen" src="./public/imagenes/pf4.jpg" alt=""></center>
    
    
    
        </div>
          </div>
          <div class="contenedoralu">
            <div class="column col-serv">
                
    <center><h2 class="titcart">Ejecución de las estancias:</h2> </center>
    
                <p class="parrafoserv2">Llevar a cabo las actividades planificadas, aplicando los conocimientos teóricos en situaciones prácticas, bajo la supervisión de profesionales experimentados.</p>
              </div>
              <div class="column col-serv">
              
    <center> <h2 class="titcart">Evaluación y Retroalimentación:</h2></center>
    
                <p class="parrafoserv2">Recibir evaluación y retroalimentación continua por parte de los supervisores y profesionales de la institución. Esto contribuye al aprendizaje y desarrollo del estudiante.</p>
              </div>
              <div class="column col-serv">
               
    <center><h2 class="titcart">certificacion:</h2></center>
    En algunos casos, recibir una certificación o constancia de las prácticas realizadas, la cual puede ser relevante para futuras oportunidades laborales.</p>
              </div>
              <div class="column col-serv">
                
    <center><h2 class="titcart">Informe y Evaluación:</h2></center>
    
                <p class="parrafoserv2">Elaborar un informe final que documente las experiencias, aprendizajes y logros obtenidos durante las prácticas.

                </p>
              </div>
            </div>
          </div>
          <br>
          <br>
          <div>
           <center>
            <a href="./registro_estancias.php" class="boton-degradado  botonsee">Registro de estancias</a>
            <a href="./estancias_vista_alumno.php" class="boton-degradado botonsee">Consulta estancias</a>
    
        </center> 
    
    </body>
    
          </div>
        <script src="/functions.js" crossorigin=""></script>
        <script src="styles_alumno.css"></script>
        <script src="styles_serviciosec.css"></script>
    </body>
    <br>
    <footer>
        <div class="footer-container">
            <div class="footer-content">
                <p>&copy; 2023 UPP Web Wizards
                </p>
            </div>
        </div>
    </footer>
    
</html>