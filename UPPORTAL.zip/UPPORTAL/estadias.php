<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./public/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles_alumno.css">
    <link rel="stylesheet" href="styles_serviciosec.css">
    <link rel="stylesheet" href="cl-icon/css/all.min.css">
    <link rel="stylesheet" href="functions.js">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <title>ESTADIAS</title>
</head>
<body class="body2">
    <header>
        <div class="logo-nav-container">
            <nav class="nav-bar ">
                <ul>
                    <li><img class="imgalum" src="./public/imagenes/logotipopaginaprin.jpg" alt=""></li>
                    <li><a href="./login.php" class="titulosnav">SALIR</a></li>
                    <li><a href="./alumnosprin.php" class="titulosnav">Principal</a></li>
                    <li><a href="./servicio.php" class="titulosnav">servicio social</a></li>
                    <li><a href="./estancias.php" class="titulosnav">Estancias</a></li>
                </ul>
            </nav>
        </div>
    </header>
    <center>
        <div>
            <div class="column col-8">
                <h1 class="alumnostit"> INFORMACION GENERAL DE ESTADIAS
                </h1>
            </div>
        </div>
        <div>
    </center>

    <div class="column col-6dos">
        <center>
            <h1 class="moretitle"> ESTADIAS EN UPP</h1>
            <br>
            <div class="bg4 ">
                <p class=" parrafoserv">
                    son vitales para la formación académica y el desarrollo profesional de los estudiantes. Proporcionan una transición crucial entre la teoría académica y la aplicación práctica en entornos laborales reales,son una piedra angular para la transición exitosa de los estudiantes al mundo laboral, contribuyendo significativamente a su crecimiento personal y profesional.
            </div>

        </center>

    </div>

    <div class="contenedoralu">
        <div class="carta">
            <h2 class="tituloserv">Proceso de Realizar Estadias:
            </h2>
            <p>
                <ul>
                    <li class="alumnotitulo">Elección de la Institución o Empresa:</li>
                    <p></p>
                    <p class="parrafoserv"> Seleccionar una institución o empresa relevante para la especialidad de la carrera, considerando los objetivos profesionales y la aplicación de conocimientos adquiridos.</p>
                    <li class="alumnotitulo">Contacto y Aprobación:</li>
                    <p></p>
                    <p class="parrafoserv"> Establecer comunicación con la entidad elegida, verificar la posibilidad de realizar estancias y obtener la aprobación, posiblemente mediante solicitud y entrevistas.</p>
                    <li class="alumnotitulo">Acuerdo o Convenio:</li>
                    <p></p>
                    <p class="parrafoserv">Formalizar acuerdos o convenios entre la institución educativa y la entidad receptora, definiendo términos, condiciones y responsabilidades.

                    </p>
                    <li class="alumnotitulo">Planificación:</li>
                    <p></p>
                    <p class="parrafoserv">Elaborar un plan detallado de las actividades a realizar durante las estancias, considerando el período específico y los objetivos de aprendizaje.

                    </p>
                </ul></p>
               
          </div>
          <div class="column col-6dosser">
    <center><img class="imagen" src="./public/imagenes/pf1.jpg" alt="">
        <br>
        <img class="imagen" src="./public/imagenes/pf2.jpg" alt=""></center>
    
    
    
        </div>
          </div>
          <div class="contenedoralu">
            <div class="column col-serv">
                
    <center><h2 class="titcart">Ejecución de las estadias:</h2> </center>
    
                <p class="parrafoserv2">Llevar a cabo las actividades planificadas, aplicando los conocimientos académicos en un entorno laboral real. Esto suele realizarse bajo supervisión y acompañamiento.</p>
              </div>
              <div class="column col-serv">
              
    <center> <h2 class="titcart">Evaluación y Retroalimentación:</h2></center>
    
                <p class="parrafoserv2">Recibir evaluación y retroalimentación continua por parte de los supervisores y profesionales de la entidad receptora..</p>
              </div>
              <div class="column col-serv">
               
    <center><h2 class="titcart">certificacion:</h2></center>
    <p class="parrafoserv2">Obtener una certificación o constancia de las estancias profesionales, acreditando la participación y los logros obtenidos. Esta certificación puede ser valiosa en el ámbito laboral.</p>
              </div>
              <div class="column col-serv">
                
    <center><h2 class="titcart">Informe y Evaluación:</h2></center>
    
                <p class="parrafoserv2">Elaborar un informe detallado al concluir las estancias, documentando las experiencias, habilidades desarrolladas y contribuciones al entorno laboral.



                </p>
              </div>
            </div>
          </div>
          <br>
          <br>
          <div>
           <center>
            <a href="./registro_estadia.php" class="boton-degradado  botonsee">Registro de estadias</a>
            <a href="./estadia_vista_alumno.php" class="boton-degradado botonsee">Consulta estadias alumnado</a>
    
        </center> 
    
    </body>
    
          </div>
        <script src="/functions.js" crossorigin=""></script>
        <script src="styles_alumno.css"></script>
        <script src="styles_serviciosec.css"></script>
    </body>
    <br>
    <footer>
        <div class="footer-container">
            <div class="footer-content">
                <p>&copy; 2023 UPP Web Wizards
                </p>
            </div>
        </div>
    </footer>
    
</html>